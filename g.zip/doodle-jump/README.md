HTML5 Doodle Jump
=================

This is a recreation of Doodle Jump that originally comes for Android and iOS devices. This game is created using awesome HTML5 API and Canvas. It does not have all of the features that the original game has (for now) like Monsters, Power ups etc.

I'll be releasing a second version of this game with more features from the original game along with sounds to make this game more fun. Stay tuned for more game releases by me :D

**Note**: This game is just a "recreation" of the original game in HTML5 and the graphics are made in Photoshop. I respect the original creators [Igor Pusenjak](http://www.limasky.com/) and his brother for their great work. I am a big fan of this game and I really love it so I decided to recreate that in HTML5 and trying to incorporate the same fun level the original creators did. 

The name of the game and images are &copy; **copyrights** by the respective creators and [Lima Sky](http://www.limasky.com/). If you like this game and want to purchase it for your phone, then you can get it for you iPhone [here](http://itunes.apple.com/in/app/doodle-jump/id307727765?mt=8) or your Android phone [here](https://play.google.com/store/apps/details?id=com.realarcade.DOJ&hl=en).

**Update**: You want to learn the process I used to create this game? Check out [this post by me](http://codetheory.in/how-i-created-my-version-of-doodle-jump-in-html5/). :)
